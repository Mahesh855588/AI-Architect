# AI/ML Mastery — The Complete 18-Month Roadmap

**Goal:** Software engineer → ML/AI engineer who can (1) crack **GATE DA**, (2) get into a good
**Master's** program, (3) compete on **Kaggle**, (4) build an **extraordinary portfolio**, and
(5) **crack interviews at top AI/ML companies** (Google, Meta, Microsoft, Amazon, OpenAI,
Anthropic, DeepMind-tier labs).

---

## How this package is organized

| Level | Folder / Zip | Focus | Duration |
|---|---|---|---|
| 1 | `Level1-Foundations` | Python, Math, DSA, SQL, Tooling | Months 1–2.5 |
| 2 | `Level2-Core-ML` | Classical ML, Classical AI, first Kaggle | Months 2.5–6 |
| 3 | `Level3-Deep-Learning` | Neural nets, PyTorch, CV, NLP, Transformers | Months 6–10 |
| 4 | `Level4-Advanced-AI` | LLMs, Generative, RL, MLOps, Big Data, ML System Design | Months 10–14 |
| 5 | `Level5-Research` | Theory, papers, LLM internals, research capstone, GATE mocks | Months 14–18 |

Every level contains **subject folders**. Every subject folder contains:

- `syllabus.md` — every topic and subtopic, with **what/why**, **resources**, **GATE-DA tags**, and the **linked exercise notebook**.
- `exercises/` — one Jupyter notebook per topic: concept recap → worked example → TODO tasks → stretch goal → portfolio-polish checklist.
- `projects.md` — portfolio projects with specs and grading rubrics.

Each level also has `00-README.md` (study order, outcomes, milestones) and `capstone.md`.

## How to study (the loop that actually works)

1. **Read** the topic in `syllabus.md` + the primary resource (book chapter / lecture).
2. **Code** the exercise notebook the same day — concept and code side by side, always.
3. **Polish** the best notebooks into GitHub repos (the notebook tells you how).
4. **Log** every solved problem/exercise in a study journal (template in Level 1 Interview-Prep).
5. **Review** weekly: redo one old exercise from memory; spaced repetition for math/GATE formulas.

**Time budget:** ~20–25 hrs/week for 18 months (~1,700 hours total). If you work full-time:
2 hrs weekdays + 6–8 hrs each weekend day.

---

## 18-month week-by-week timeline

### Months 1–2.5 — Level 1: Foundations
- **Weeks 1–2:** Python mastery (core → OOP → generators/decorators) + Tooling (git, environments).
- **Weeks 3–4:** NumPy/Pandas/Matplotlib deeply + SQL & databases.
- **Weeks 5–7:** Linear algebra + calculus & optimization (code every concept in NumPy).
- **Weeks 8–9:** Probability & statistics (GATE depth).
- **Weeks 10–11:** DSA in Python + start LeetCode easy ladder (Interview-Prep).
- **Milestone:** Level 1 capstone (data-analysis project) on GitHub. 50 LeetCode easy.

### Months 2.5–6 — Level 2: Core ML
- **Weeks 12–14:** EDA & preprocessing; feature engineering; PCA and friends.
- **Weeks 15–19:** Supervised learning — every algorithm: theory → from-scratch → sklearn.
- **Weeks 20–21:** Unsupervised learning; anomaly detection.
- **Weeks 22–23:** Model evaluation, metrics, tuning; imbalanced data.
- **Weeks 24–25:** Statistical ML theory (MLE/MAP, information theory, bias-variance formally) + Classical AI (search, logic — GATE AI section).
- **Week 26:** Kaggle: Titanic + House Prices + one live playground competition.
- **Milestone:** 3 polished ML repos; Kaggle profile live; 100+ LeetCode; GATE PYQ pass 1 for math/ML.

### Months 6–10 — Level 3: Deep Learning
- **Weeks 27–28:** Neural nets **from scratch** in NumPy (backprop by hand).
- **Weeks 29–31:** PyTorch end to end; optimization & regularization.
- **Weeks 32–35:** CNNs & computer vision (classification → detection → segmentation).
- **Weeks 36–40:** NLP: embeddings → RNN/LSTM → attention → **Transformer from scratch** → Hugging Face fine-tuning.
- **Weeks 41–43:** DL practice (experiment tracking, debugging) + image or NLP Kaggle competition.
- **Milestone:** Transformer-from-scratch repo (a portfolio centerpiece), 2 DL projects deployed as demos, Kaggle competition finished.

### Months 10–14 — Level 4: Advanced AI & Production
- **Weeks 44–47:** LLMs: fine-tuning (LoRA/QLoRA), RAG pipeline, agents, evaluation.
- **Weeks 48–50:** Generative models: VAE → GAN → diffusion.
- **Weeks 51–53:** Reinforcement learning: MDPs → DQN → PPO.
- **Weeks 54–56:** MLOps: Docker, FastAPI serving, CI/CD, monitoring; deploy 2 projects live.
- **Weeks 57–58:** Big data (Spark) + specialized domains (time series, recsys, graph ML).
- **Weeks 59–60:** **ML System Design** (interview subject) + serious Kaggle competition (target: medal).
- **Milestone:** 2 deployed end-to-end apps with live URLs; ML system design fluency; Kaggle medal attempt.

### Months 14–18 — Level 5: Research + GATE + Interviews
- **Weeks 61–64:** Learning theory + optimization theory; paper-reading program starts (1 paper/week from the curated list).
- **Weeks 65–70:** Reproduce 2–3 papers; LLM internals (attention variants, RLHF/DPO, interpretability).
- **Weeks 71–74:** Research capstone: reproduction + novel extension, written as a tech report.
- **Weeks 75–78:** **GATE DA sprint**: formula sheets, PYQs, full mock exams (pack included in Level 5). *(GATE is held in February — align this sprint to land 6–8 weeks before your exam date.)*
- **Ongoing (final 3 months):** mock interviews weekly; apply to companies / Master's programs.
- **Milestone:** research-grade capstone + tech report, GATE mock scores at target, interview-ready.

---

## GATE DA syllabus → where it's covered

| GATE DA Section | Covered in |
|---|---|
| Probability & Statistics | Level 1 `04-Probability-Statistics` (full), reinforced in Level 2 theory |
| Linear Algebra | Level 1 `02-Linear-Algebra` (full) |
| Calculus & Optimization | Level 1 `03-Calculus-Optimization` (full) |
| Programming, Data Structures & Algorithms (Python) | Level 1 `01-Python-Mastery` + `05-DSA-Python` (full) |
| Database Management & Warehousing | Level 1 `06-SQL-Databases` (full) |
| Machine Learning (supervised + unsupervised) | Level 2 (all subjects; every listed algorithm has a from-scratch exercise) |
| Artificial Intelligence (search, logic, reasoning under uncertainty) | Level 2 `06-Classical-AI` (full) |

GATE strategy: master content in Levels 1–2 (months 1–6), keep a weekly PYQ (previous-year
questions) habit from month 4, then the dedicated mock-exam sprint in Level 5
(`Level5-Research/07-GATE-DA-Prep-Pack`: formula sheets + subject-wise problem sets + full mocks).

## Kaggle ladder

1. **Level 2:** Titanic → House Prices → one live *Playground* competition (learn the full workflow).
2. **Level 3:** one image or NLP competition (deep learning pipeline end to end).
3. **Level 4:** one serious live competition — target a **bronze/silver medal** (ensembling, validation discipline).
4. **Level 5:** study winning solutions; advanced techniques (stacking, pseudo-labeling, adversarial validation); aim higher.

Also publish **Kaggle notebooks** (EDA write-ups earn votes → Notebooks Expert tier → visibility).

## Portfolio strategy (what "extraordinary" means)

By month 18 your GitHub should have **8–12 pinned-quality repos**:

1. From-scratch ML library (Level 2) — every classical algorithm, tested, documented.
2. Neural-network framework from scratch in NumPy (Level 3).
3. **Transformer from scratch + trained mini-GPT** (Level 3) — centerpiece.
4. A CV project and an NLP project, each **deployed with a live demo** (Levels 3–4).
5. RAG/LLM application with an evaluation harness (Level 4).
6. End-to-end MLOps project: data → training → CI/CD → serving → monitoring (Level 4).
7. Kaggle competition solution write-ups (Levels 2–5).
8. **Research capstone: paper reproduction + extension, with tech report** (Level 5).

Every repo: clean README with a results table and plots, reproducible environment, tests where
sensible, a short demo GIF/screenshot. Write a blog post (or LinkedIn/X thread) per major
project — recruiters and admissions committees read these.

## Top-company interview roadmap

| When | What to be ready for | Where it's prepped |
|---|---|---|
| Month 3 | LeetCode easy/medium fluency, big-O | L1 `Interview-Prep` |
| Month 6 | ML breadth (explain/derive any classical algorithm), stats puzzles, SQL rounds | L2 `Interview-Prep` |
| Month 10 | ML coding rounds (k-means / logreg / backprop / attention from scratch, timed), DL depth | L3 `Interview-Prep` |
| Month 14 | **ML system design**, take-home assignments, behavioral (STAR from your projects) | L4 `Interview-Prep` |
| Months 15–18 | Research interviews (paper discussions), company-specific loops, weekly mocks, resume | L5 `Interview-Prep` |

## Core bookshelf (referenced throughout; specific chapters cited in each syllabus)

- *Mathematics for Machine Learning* — Deisenroth, Faisal, Ong (free PDF: mml-book.github.io)
- *An Introduction to Statistical Learning* (ISLR, free: statlearning.com) and *Elements of Statistical Learning* (ESL, free: hastie.su.domains/ElemStatLearn)
- *Hands-On Machine Learning* — Aurélien Géron (3rd ed., O'Reilly)
- *Deep Learning* — Goodfellow, Bengio, Courville (free: deeplearningbook.org)
- *Dive into Deep Learning* (free, runnable: d2l.ai)
- *Reinforcement Learning: An Introduction* — Sutton & Barto (free: incompleteideas.net/book/the-book.html)
- *Designing Machine Learning Systems* + *Machine Learning Interviews* — Chip Huyen (huyenchip.com)
- Courses: CS229 (ML), CS231n (CV), CS224n (NLP), fast.ai, Karpathy's *Neural Networks: Zero to Hero* (YouTube), Hugging Face course (hf.co/learn), Made With ML (madewithml.com)

## Rules for the journey

1. **Never read without coding.** Every concept gets a notebook the same day.
2. **From scratch first, library second.** You only own what you can implement.
3. **Ship publicly.** Ugly-but-public beats perfect-but-private.
4. **Consistency beats intensity.** 20 hrs/week × 78 weeks wins.
5. **When stuck > 45 min:** write down the confusion precisely, then look it up. The write-up is the learning.
